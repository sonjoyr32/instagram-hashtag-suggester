# Instagram Content Hashtag Suggester

## Overview
This Android app allows users to "import" their Instagram posts (simulated for demo), analyzes their captions, and suggests hashtags for their posts.

## Features
- (Simulated) Import Instagram posts after authentication
- Analyze captions to generate hashtag suggestions
- Simple, clean UI

## Instagram API Notice
Instagram restricts API access for personal content to approved apps. For a production version, you must:
- Register your app with Facebook Developers
- Implement OAuth login
- Use Instagram Graph API to fetch user media

This demo uses static/mock content for simplicity.

## Build Instructions
1. Open the project in Android Studio.
2. Run on an emulator or device.
3. Build APK via Build > Build bundle(s)/APK(s) > Build APK(s).

## Demo Credentials
No credentials needed for this mock demo.
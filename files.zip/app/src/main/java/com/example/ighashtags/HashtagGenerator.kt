package com.example.ighashtags

object HashtagGenerator {
    private val commonWords = setOf("the", "and", "at", "with", "for", "on", "a", "an", "in", "of", "to", "is", "it")

    fun generateHashtags(caption: String): List<String> {
        val words = caption.lowercase()
            .replace(Regex("[^a-z0-9 ]"), "")
            .split(" ")
            .filter { it.isNotBlank() && it !in commonWords }
        val hashtags = words.distinct().map { "#$it" }
        // Add some fixed or trending hashtags as demo
        val extraHashtags = listOf("#instagood", "#photooftheday", "#viral")
        return (hashtags + extraHashtags).take(8)
    }
}
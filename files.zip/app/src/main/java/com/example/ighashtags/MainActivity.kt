package com.example.ighashtags

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var captionInput: EditText
    private lateinit var generateButton: Button
    private lateinit var hashtagsView: TextView
    private lateinit var mockImportButton: Button
    private val mockCaptions = listOf(
        "Sunset at the beach with friends",
        "Delicious homemade pizza for dinner",
        "Workout complete! Feeling great",
        "Exploring the mountains #adventure"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        captionInput = findViewById(R.id.captionInput)
        generateButton = findViewById(R.id.generateButton)
        hashtagsView = findViewById(R.id.hashtagsView)
        mockImportButton = findViewById(R.id.mockImportButton)

        generateButton.setOnClickListener {
            val caption = captionInput.text.toString()
            val hashtags = HashtagGenerator.generateHashtags(caption)
            hashtagsView.text = hashtags.joinToString(" ")
        }

        mockImportButton.setOnClickListener {
            // Simulate importing a random Instagram caption
            val randomCaption = mockCaptions.random()
            captionInput.setText(randomCaption)
            Toast.makeText(this, "Imported: \"$randomCaption\"", Toast.LENGTH_SHORT).show()
        }
    }
}